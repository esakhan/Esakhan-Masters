# HIGH-RIDGE CONSTRUCTION: Weekly Payslip Program

import random   

workers = [] 

for i in range(1, 401):  # 1 to 400
    worker = {
        "id": i,                              
        "gender": random.choice(["Male", "Female"]), 
        "salary": random.randint(3000, 35000)  # random salary (for testing)
    }
    workers.append(worker) 

for worker in workers:
    try:
    
        worker_id = worker["id"]
        gender = worker["gender"]
        salary = worker["salary"]

    
        level = "UNASSIGNED"

        if salary > 7500 and salary < 30000 and gender == "Female":
            level = "A5-F"

        elif salary > 10000 and salary < 20000:
            level = "A1"

        print("========== PAYSLIP ==========")
        print("Worker ID       :", worker_id)
        print("Gender          :", gender)
        print("Weekly Salary   : $", salary)
        print("Employee Level  :", level)
        print("=============================\n")

    except KeyError:
        print("ERROR: A worker record is missing a required field.\n")

    except Exception as e:
        print("ERROR: Something went wrong ->", e, "\n")

