# HIGHRIDGE CONSTRUCTION - Weekly Payslip Generator in R

set.seed(123)   # Makes random values repeatable 

worker_id <- 1:400

gender <- sample(c("Male", "Female"), 
                 size = 400, 
                 replace = TRUE)

salary <- sample(3000:35000, 
                 size = 400, 
                 replace = TRUE)

workers <- data.frame(worker_id, gender, salary)


for(i in 1:nrow(workers)){

  tryCatch({
    
    id <- workers$worker_id[i]
    gen <- workers$gender[i]
    sal <- workers$salary[i]
    
    level <- "UNASSIGNED"
    
 
    if(sal > 7500 && sal < 30000 && gen == "Female"){
      level <- "A5-F"
    }
    

    else if(sal > 10000 && sal < 20000){
      level <- "A1"
    }
    
    cat("========== PAYSLIP ==========\n")
    cat("Worker ID      :", id, "\n")
    cat("Gender         :", gen, "\n")
    cat("Weekly Salary  : $", sal, "\n")
    cat("Employee Level :", level, "\n")
    cat("=============================\n\n")
    
  }, error = function(e){
    
    cat("ERROR: Something went wrong ->", e$message, "\n")
    
  })
}




