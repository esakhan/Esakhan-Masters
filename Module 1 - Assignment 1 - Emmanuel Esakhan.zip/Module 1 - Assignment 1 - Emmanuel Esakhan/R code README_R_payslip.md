Highridge Construction Company Weekly Payslip Generator - R Program

 
  OVERVIEW
 
  This R program generates weekly
  payslips for 400 workers
  automatically. It creates worker
  data dynamically, assigns employee
  levels based on salary and gender,
  and prints a formatted payslip for
  each worker.


  HOW TO RUN THE PROGRAM


STEP 1: Save the File Save the script as:

    payslip_program.R

STEP 2: Open R or RStudio

STEP 3: Set Your Working Directory Make sure R is pointing to the folder
where the file is saved.

STEP 4: Run the Program

Type:

    source("payslip_program.R")

Then press ENTER.

 
  WHAT THE PROGRAM DOES

✔ Creates 400 workers automatically\
✔ Assigns random salaries and genders\
✔ Uses a for loop to generate payslips\
✔ Applies conditional logic:

    - Salary > 10,000 and < 20,000 → Level A1
    - Salary > 7,500 and < 30,000 AND Female → Level A5-F

✔ Uses tryCatch() for error handling


  EXPECTED OUTPUT


========== PAYSLIP ========== Worker ID : 1 Gender : Female Weekly
Salary : \$ 15000 Employee Level : A5-F =============================


  TROUBLESHOOTING


Problem: File not found Solution: Ensure the working directory is
correct.

Problem: Script does not run Solution: Confirm the file extension is .R


  AUTHOR


Emmanuel Esakhan -- Highridge Construction Assignment
