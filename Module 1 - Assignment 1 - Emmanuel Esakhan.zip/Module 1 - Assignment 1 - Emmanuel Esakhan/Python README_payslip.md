Highridge Construction Company Weekly Payslip Generator - Python Program

  OVERVIEW
  
  This Python program automatically
  generates weekly payslips for 400
  workers. It creates workers
  dynamically, assigns employee
  levels based on salary and gender,
  and prints a formatted payslip for
  each worker.


  HOW TO RUN THE PROGRAM

STEP 1: Save the Python File as:

    payslip_program.py

STEP 2: Open Terminal / Command Prompt Navigate to the folder where the
file is saved.

STEP 3: Run the Program

    python payslip_program.py


  PROGRAM FEATURES

✔ Creates 400 workers automatically\
✔ Uses a for loop to generate payslips\
✔ Applies conditional logic:

    - Salary > 10,000 and < 20,000 → Level A1
    - Salary > 7,500 and < 30,000 AND Female → Level A5-F

✔ Includes exception handling to prevent crashes


  EXPECTED OUTPUT


========== PAYSLIP ========== Worker ID : 1 Gender : Female Weekly
Salary : \$ 15000 Employee Level : A5-F =============================

  TROUBLESHOOTING


Problem: 'python is not recognized' Solution: Reinstall Python and
ensure "Add Python to PATH" is checked.

Problem: Program does not run Solution: Confirm the file name ends with
.py


  AUTHOR
  
Emmanuel Esakhan -- Highridge Construction Assignment
